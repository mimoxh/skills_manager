﻿Skills Manager
==============

Windows portable build.

Run:
1. Double-click Skills Manager.exe.
2. The app creates a default repository and reuses existing local state.

Notes:
- Tauri 2 desktop app with a Rust backend.
- This portable package does not require a browser or localhost preview service.
- Source development uses React, TypeScript, Vite, and Rust.
